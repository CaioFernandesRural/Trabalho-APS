<?php

namespace App\models;

class Organizador extends Pessoa {
    
}