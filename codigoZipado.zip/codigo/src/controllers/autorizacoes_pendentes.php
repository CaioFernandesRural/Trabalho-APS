<?php
session_start();
#requireValidSession();

loadTemplateView('autorizacoes_pendentes');