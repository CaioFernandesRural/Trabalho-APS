<?php
session_start();
#requireValidSession();

loadTemplateView('artigo');