<?php
session_start();
#requireValidSession();

loadTemplateView('evento');