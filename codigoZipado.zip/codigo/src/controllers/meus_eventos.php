<?php
session_start();
requireValidSession();



loadTemplateView('meus_eventos');