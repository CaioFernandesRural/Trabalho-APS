<header class="container">
    <a href="/home.php" class="logo">
        <div>
            <h3>Alexandria</h3>
        </div>
    </a>
    <label id="pesquisa">
        <input type="text" id="barra_pesquisa" placeholder="Buscar">
        <img src="../assets/img/icon_lupa.png" id="icon_lupa">
    </label>
    <a href="/login.php"><img src="../assets/img/icon_person.png" id="icon_person"></a>
    <!-- Logado
    <img src="../../public/assets/img/logout.png" id="icon_logout">
-->
</header>
<!-- Administrador
<nav>
    <a href="">Autorizações Pendentes</a>
    <a href="">Eventos</a>
</nav>  
-->
<!-- Cadastrador
<nav>
    <a href="">Meus Eventos</a>
    <a href="">Eventos</a>
</nav>  
-->