USE alexandria;

/*SELECT * FROM usuario ;

DELETE FROM usuario WHERE id > 1;

SELECT * FROM evento;

ALTER TABLE Evento DROP COLUMN ano;*/

SELECT * FROM artigo;